from flask import Flask,render_template,jsonify,request,redirect
from models import db,Data
# from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.secret_key = "secret key"
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:12345@localhost/mydb'
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)
# db = SQLAlchemy(app)

# class Data(db.Model):
#     id = db.Column(db.Integer,primary_key=True,autoincrement=True)
#     name = db.Column(db.String(100),nullable = True)
#     email = db.Column(db.String(100),unique=True,nullable=True)
#     phone = db.Column(db.String(100),unique=True,nullable=True)

#     def __init__(self,name,email,phone):
#         self.name = name 
#         self.email = email
#         self.phone = phone

with app.app_context():
    db.create_all()


@app.route('/',methods=["GET","POST"])
def hello():
    if request.method == "POST":
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
    
        new_user = Data(name=name,
                        email=email,
                       phone=phone )
        try :
            db.session.add(new_user)
            db.session.commit()
            return redirect('/')
        except Exception as e :
            print(f"ERROR{e}")
            return f"ERROR{e}"
    else:
        users = Data.query.all()
        print(users)
        content = {'users' :users}
    return render_template("index.html",content=content)

@app.route('/update/<int:id>',methods=["GET","POST"])
def update(id):
    # users = Data.query.all()
    users = Data.query.get_or_404(id)

    if not users:
        abort(404)

    if request.method == "POST":
        # users.id = id
        users.name = request.form['name']
        users.email = request.form['email']
        users.phone = request.form['phone']
    
        
        try :
            # db.session.add(new_user)
            db.session.commit()
            return redirect('/')
        except Exception as e :
            print(f"ERROR{e}")
            return render_template("index.html")
    else:
        content = {'users' :users}
        return render_template('update_data.html',content=content)
    
@app.route('/delete/<int:id>')
def delete(id):
    delete_data = Data.query.get_or_404(id)

    try :
        db.session.delete(delete_data)
        db.session.commit()
        return redirect('/')
    
    except Exception as e :
        print(f"ERROR{e}")
        return f"ERROR{e}"



if __name__ == '__main__':
    app.run(debug=True)
